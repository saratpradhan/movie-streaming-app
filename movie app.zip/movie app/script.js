
/*We did here is a logged in to moviedb  at registration it asks for url just write localhost and name of ur app . website(developers.moviedb.org) and we copied a api request link 
the link is of srting through their databse at the end of link u can see
we pased our api_key that we got from the website when we register . we just pasted that here

furthermore when u read the link u see it does sort by popularity*/

const main= document.getElementById('main')
const API_URL = 'https://api.themoviedb.org/3/discover/movie?include_adult=false&include_video=false&language=en-US&sort_by=popularity.desc&api_key=6db69e72501b620cc2c99ac851ea1686&page=1' 

const IMG_PATH = 'https://image.tmdb.org/t/p/w1280'
//U GOT THIS AS AN EG LINK IN IMAGES SECTION 

const SEARCH_API = 'https://api.themoviedb.org/3/search/movie?api_key=6db69e72501b620cc2c99ac851ea1686&query="'
/*i copied api url link and changed discover to search and gave my api key to it*/



const form = document.getElementById('form')
const search = document.getElementById('search')

//get initial movies 
getMovies(API_URL)
async function getMovies(url)
 {
    const res = await fetch(url)
    const data = await res.json()
    showMovies(data.results) //made a function SEE BELOW
}

//this below functionality is to put the fetched data in our DOM
//REMEMBER getmovies function's job is tu fetch the movies data via URL

function showMovies(movies)
{

//Initially the movies ;isted on page are fetched by api but when we search some movies we want that fetched movies from url should go and whatever movies we are searching should come 
//so we made our innerhtml data empty for instance
    main.innerHTML ='' 
    movies.forEach((movie) =>
     {

        const { title, poster_path, vote_average,
        overview} = movie

        const  movieEl = document.createElement('div')
        movieEl.classList.add('movie')

        movieEl.innerHTML = `

        
              <img src="${IMG_PATH + poster_path} " alt="${title}">

              <div class="movie-info">
            <h3>${title}</h3>
            <span class="${getClassByRate(vote_average)}">${vote_average}</span>
        </div>


              <div class="overview">
            <h3>OverView</h3>
            ${overview}
              </div>

        
         `

   
            main.appendChild(movieEl)
        
    });

    }

function getClassByRate(vote)
{
    if(vote>=7) {
        return 'green'
    }else if(vote>=5) {
        return 'orange'
    } else {
        return'red'
    
    } 
}

form.addEventListener('submit',(e)=>
{
    e.preventDefault()

    const searchTerm = search.value

    if(searchTerm && searchTerm !=='')
    {
        getMovies(SEARCH_API + searchTerm)

        search.value = ''
    }else {
        window.location.reload()
    }
})
